import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFile{
    public static void main(String[] args) throws FileNotFoundException{
        File file= new File ("DATA.in");
        Scanner readFile=new Scanner(file);
        while(readFile.hasNextLine()){
            String line=readFile.nextLine();
            System.out.println(line);
        }
        readFile.close();
    }
}
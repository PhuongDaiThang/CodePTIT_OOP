import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFile {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("DATA.in");
        Scanner readFile = new Scanner(file);
        long sum = 0;

        while (readFile.hasNextLine()) {
            String line = readFile.nextLine();
            for (String part : line.split("\\s+")) {
                try {
                    int number = Integer.parseInt(part);
                    sum += number;
                } catch (NumberFormatException e) {
                }
            }
        }
        readFile.close();
        System.out.println(sum);
    }
}


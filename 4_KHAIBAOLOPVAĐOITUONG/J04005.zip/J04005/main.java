package J04005;

import java.util.Scanner;
public class main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s=sc.nextLine();
        Student s1 = new Student();
        s1.setName(s);
        s = sc.nextLine();
        s1.setDoB(s);
        double x=sc.nextDouble();
        s1.setSubject1(x);
        x = sc.nextDouble();
        s1.setSubject2(x);
        x = sc.nextDouble();
        s1.setSubject3(x);
        System.out.printf("%s %s %.1f",s1.getName(),s1.getDoB(),s1.sumPoint());
    }
}

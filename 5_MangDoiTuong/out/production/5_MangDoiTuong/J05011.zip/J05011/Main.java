public class Main {
    public static void main(String[] args) {
        calcTime cT=new calcTime();
        cT.calc();
    }
}

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while (t-- > 0) {
            soPhuc x = new soPhuc(sc.nextInt(), sc.nextInt());
            soPhuc y = new soPhuc(sc.nextInt(), sc.nextInt());
            soPhuc c=x.cong(y).nhan(x);
            soPhuc d=x.cong(y).nhan(x.cong(y));
            System.out.println(c + ", " + d);
        }
    }
}
